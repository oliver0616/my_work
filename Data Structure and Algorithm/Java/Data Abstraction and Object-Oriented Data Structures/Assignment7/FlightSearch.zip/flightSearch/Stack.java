package flightSearch;

public class Stack<E> implements StackInterface<E> {


	/**
	 * Creates an empty stack
	 */
	public Stack() {
	}
	
	
	public boolean isEmpty() {
		return false;
	}

	
	public void popAll() {	
	}


	public void push(E newItem) throws StackException {
	}


	public E pop() throws StackException {
		return null;
	}

	
	public E peek() throws StackException {
		return null;
	}

}
