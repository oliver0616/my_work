package flightSearch;

public class StackException extends RuntimeException {

	private static final long serialVersionUID = 5443041180949666827L;

	StackException(String s)
	{
		super(s);
	}
	
}
