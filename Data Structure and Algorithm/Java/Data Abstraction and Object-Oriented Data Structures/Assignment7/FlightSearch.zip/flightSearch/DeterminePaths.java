package flightSearch;

public class DeterminePaths {

	public static void main(String[] args) {

	}

}
