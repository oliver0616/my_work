package counter;

import junit.framework.TestCase;

public class TestStepCounter extends TestCase {

	private StepCounter x, y;
	
	protected void setUp() {
		x = new StepCounter(3);
		y = new StepCounter(6, 4);
	}
	
	public void testOneParamConstructor() {
		assertEquals("Counter value:", 0, x.getCounter());
	}
	
	public void testTwoParamConstructor() {
		assertEquals("Counter value:", 6, y.getCounter());
	}
	
	public void testToString() {
		assertEquals("Counter value:", "0", x.toString());
		assertEquals("Counter value:", "6", y.toString());
	}
	
	public void testIncrement() {
		x.increment();
		y.increment();
		assertEquals("Counter value:", 3, x.getCounter());
		assertEquals("Counter value:", 10, y.getCounter());
	}
	
	public void testDecrement() {
		x.decrement();
		y.decrement();
		assertEquals("Counter value:", -3, x.getCounter());
		assertEquals("Counter value:", 2, y.getCounter());
	}
	
	public void testReset() {
		x.increment();
		y.increment();
		x.reset();
		y.reset();
		assertEquals("Counter value:", 0, x.getCounter());
		assertEquals("Counter value:", 6, y.getCounter());
		
		x.decrement();
		y.decrement();
		x.reset();
		y.reset();
		assertEquals("Counter value:", 0, x.getCounter());
		assertEquals("Counter value:", 6, y.getCounter());
	}
	
	/*******************************************************/
	
	public void testNotSame() {
		assertNotSame(x, y);
		
		x = y;
		assertSame(x, y);
	}
	
	public void testNoException() {
		try {
			x.increment();
		}
		catch(Exception e) {
			fail("Exception was thrown on increment");
		}
	}
}
