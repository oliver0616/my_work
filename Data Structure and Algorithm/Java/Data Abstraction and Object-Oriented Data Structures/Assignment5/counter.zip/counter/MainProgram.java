package counter;

public class MainProgram {

	public static void main(String[] args) {
		
		Counter x = new Counter(5);
		System.out.println(x);
		x.increment();
		x.increment();
		System.out.println(x);
		
		StepCounter y = new StepCounter(5);
		System.out.println(y);
		y.increment();
		y.increment();
		System.out.println(y);

	}

}
