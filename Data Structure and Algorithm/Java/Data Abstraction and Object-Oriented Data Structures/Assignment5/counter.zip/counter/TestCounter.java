package counter;

import junit.framework.TestCase;

public class TestCounter extends TestCase {

	private Counter x, y;
	
	protected void setUp() {
		x = new Counter();
		y = new Counter(6);
	}
	
	public void testDefaultConstructor() {
		assertEquals("Counter value:", 0, x.getCounter());
	}
	
	public void testOneParamConstructor() {
		assertEquals("Counter value:", 6, y.getCounter());
	}
	
	public void testToString() {
		assertEquals("Counter value:", "0", x.toString());
		assertEquals("Counter value:", "6", y.toString());
	}
	
	public void testIncrement() {
		x.increment();
		y.increment();
		assertEquals("Counter value:", 1, x.getCounter());
		assertEquals("Counter value:", 7, y.getCounter());
	}
	
	public void testDecrement() {
		x.decrement();
		y.decrement();
		assertEquals("Counter value:", -1, x.getCounter());
		assertEquals("Counter value:", 5, y.getCounter());
	}
	
	public void testResetAfterInc() {
		x.increment();
		y.increment();
		x.reset();
		y.reset();
		assertEquals("Counter value:", 0, x.getCounter());
		assertEquals("Counter value:", 6, y.getCounter());
	}
	
	public void testResetAfterDec() {
		x.decrement();
		y.decrement();
		x.reset();
		y.reset();
		assertEquals("Counter value:", 0, x.getCounter());
		assertEquals("Counter value:", 6, y.getCounter());
	}
}
